package mvc

import javax.swing.JLabel

// TODO 1: make this class react to changes in the model
class LabelView(private val model: PairDataSet) : JLabel() {
    init {
        text = "$model"
    }
}