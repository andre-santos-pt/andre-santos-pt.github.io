package mvc


/**
 * Controller: wires model and view
 */
fun main() {
    val model = PairDataSet(Pair(10, 10), Pair(20, 20), Pair(30, 30))

    val view = window {
        title = "MVC Exercise"
        size = 600 x 300

        content {
            columns = 1
            +panel {
                +LabelView(model)
                +button("add") {
                    val pair = dualPrompt("Values?", "first","second", "0", "0")
                    pair?.let {
                        model.add(Pair(pair.first.toInt(), pair.second.toInt()))
                    }
                }
            }
            +CanvasView(model) // TODO 2: react to clicks
            +TableView(model) // TODO 3: react to edits // TODO 4: react to deletes
        }
    }
    view.open()
}





